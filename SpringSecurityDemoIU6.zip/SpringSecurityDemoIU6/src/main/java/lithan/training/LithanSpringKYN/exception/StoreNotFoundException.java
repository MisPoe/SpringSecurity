package lithan.training.LithanSpringKYN.exception;

public class StoreNotFoundException extends Exception {

	public StoreNotFoundException(String string) {
		System.out.println("Store Not Found Exception");
	}

}
