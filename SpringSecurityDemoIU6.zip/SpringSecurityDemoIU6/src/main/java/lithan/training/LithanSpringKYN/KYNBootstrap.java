package lithan.training.LithanSpringKYN;

import lithan.training.LithanSpringKYN.config.JPAConfig;
import lithan.training.LithanSpringKYN.config.SecurityConfig;
import lithan.training.LithanSpringKYN.config.WebMvcConfig;
import org.springframework.web.servlet.support.AbstractAnnotationConfigDispatcherServletInitializer;

//web.xml
public class KYNBootstrap extends AbstractAnnotationConfigDispatcherServletInitializer {
	
    protected Class<?>[] getRootConfigClasses() {
        return new Class[]{JPAConfig.class, SecurityConfig.class};
    }

    protected Class<?>[] getServletConfigClasses() {
        return new Class[]{WebMvcConfig.class};
    }

    protected String[] getServletMappings() {
        return new String[]{"/"};
    }
}
