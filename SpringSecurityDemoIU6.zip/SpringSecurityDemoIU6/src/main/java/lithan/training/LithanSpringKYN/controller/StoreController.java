package lithan.training.LithanSpringKYN.controller;


import lithan.training.LithanSpringKYN.entities.Store;
import lithan.training.LithanSpringKYN.exception.StoreNotFoundException;
import lithan.training.LithanSpringKYN.services.StoreService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.CollectionUtils;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import java.security.Principal;
import java.util.List;

@Controller
public class StoreController {

    private static Logger logger = LoggerFactory.getLogger(StoreController.class);

    @Autowired
    private StoreService storeService;

    @RequestMapping(value="/",  method= RequestMethod.GET)
    public String handleRootRequest(Model model) {
        return "redirect:stores";
    }

    @RequestMapping(value="stores",  method= RequestMethod.GET)
    public String viewStores(Model model) throws StoreNotFoundException {
    	
        List<Store> stores = storeService.getAllStores();
        
        System.out.println("Get All Store Results From Controller "+stores.toString()+stores.size());
        
        if(CollectionUtils.isEmpty(stores)) {
        	 throw new StoreNotFoundException("store not found");
        	 }
        
        
        if(!CollectionUtils.isEmpty(stores)) {
            model.addAttribute("stores", stores);
        }
        return "view_stores";
    }
    
    /*// For Exception Handling //
    @ExceptionHandler(StoreNotFoundException.class)
    public String handleStoreNotFoundException(Model model, Exception ex) {
    // Add error message to the view. This should be a user friendly message.
    model.addAttribute("error_message", "Sorry, the store doesn't exist. Do you want to try another store?");
    return "view_stores";
    }*/

    
    

    @RequestMapping(value="stores",  method = {RequestMethod.POST, RequestMethod.PUT})
    public String saveStore(@RequestParam(value="id", required = false) Long id,
                            @RequestParam("name") String name,
                            @RequestParam("phone_number") String phoneNumber,
                            @RequestParam("email") String email,
                            @RequestParam(value="address", required=false) String address,
                            @RequestParam(value="category_id", required=false) Integer category_id,
                            @RequestParam(value="category_name", required=false) String categoryName,
                            Model model) {
        Store store = new Store();
        store.setId(id != null ? id: 0);
        store.setName(name);
        store.setPhoneNumber(phoneNumber);
        store.setEmail(email);

        logger.debug("Store name:{}, phone_number: {}", store.getName(), store.getPhoneNumber());
        
        Store savedStore = storeService.saveStore(store);
        model.addAttribute("stores", storeService.getAllStores());
        return "view_stores";
    }
    
    
}
