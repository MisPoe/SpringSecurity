package lithan.training.LithanSpringKYN.exception;

import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

@ControllerAdvice
public class GlobalExceptionHandler {
	
	 // For Exception Handling //
    @ExceptionHandler(StoreNotFoundException.class)
    public String handleStoreNotFoundException(Model model, Exception ex) {
    // Add error message to the view. This should be a user friendly message.
    model.addAttribute("error_message", "Sorry, the store doesn't exist. Do you want to try another store?");
    return "view_stores";
    //return "error";
    }

}
