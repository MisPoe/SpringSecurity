package lithan.training.LithanSpringKYN.services;


import lithan.training.LithanSpringKYN.controller.StoreController;
import lithan.training.LithanSpringKYN.daos.StoreRepository;
import lithan.training.LithanSpringKYN.entities.Store;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.util.List;
import java.util.Optional;

@Service
@Transactional
public class StoreService {
   private static final Logger logger = LoggerFactory.getLogger(StoreService.class);

    @Autowired
    private StoreRepository storeRepository;

    public List<Store> getAllStores() {
    	logger.debug("..........*******In Get All Store Service method*****..........");
        return storeRepository.findAll();
    }

    public Optional<Store> findStoreByEmail(String emailId) {
        return storeRepository.findByEmail(emailId);
    }
//used for both update and Save user
    public Store saveStore(Store store) {
        Store dbStore = store;
        if (store.getId() > 0) {
            Optional<Store>  tmpStore = storeRepository.findById(store.getId());
            if(tmpStore.isPresent()) {
                dbStore = tmpStore.get(); // old object
                dbStore.setName(store.getName());
                dbStore.setEmail(store.getEmail());
                dbStore.setPhoneNumber(store.getPhoneNumber());
            }
        }
        Store savedStore = storeRepository.save(dbStore);
        return savedStore;
    }

}
