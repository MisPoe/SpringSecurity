package lithan.training.LithanSpringKYN.test;

import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.context.web.WebAppConfiguration;

import lithan.training.LithanSpringKYN.config.JPAConfig;
import lithan.training.LithanSpringKYN.config.SecurityConfig;
import lithan.training.LithanSpringKYN.config.WebMvcConfig;
import lithan.training.LithanSpringKYN.entities.Store;
import lithan.training.LithanSpringKYN.services.StoreService;

@ExtendWith(SpringExtension.class)
@ContextConfiguration(classes={WebMvcConfig.class, JPAConfig.class, SecurityConfig.class})
@WebAppConfiguration
public class KYN_Unit_Test {

	/* Autowire in the service we want to test */
	@Autowired
	private StoreService storeService;

	@Bean
	public StoreService storeService() {
		return new StoreService();
	}


	/*@Test
	 public void testGetAllStore() {
		// Execute the service call
        List<Store> stores = storeService.getAllStores();
        // verify the result
        Assertions.assertEquals(5, stores.size()); 

	 }*/
	
	
	@Test
	 public void testfindStoreMethod() {
		//Check the store is exist or not
		// Execute the service call
		Optional<Store> store = storeService.findStoreByEmail("abc@gmail.com");
       // verify the result
		Assertions.assertNotNull(store.get());
	 }
	
	@Test
	 public void testSaveStoreMethod() {
		//Check the store Save or Not
		
		//prepare the new store data
		Store teststore=new Store();
		teststore.setId((long)3);
		teststore.setName("Test Store");
		teststore.setEmail("teststore@gmail.com");
		teststore.setPhoneNumber("12324232");
		teststore.setAddress("Myanmar");
		
		// Execute the service call
		Store store = storeService.saveStore(teststore);
      
		// verify the result
		Assertions.assertNotNull(store);
	 }
	 
	

}
