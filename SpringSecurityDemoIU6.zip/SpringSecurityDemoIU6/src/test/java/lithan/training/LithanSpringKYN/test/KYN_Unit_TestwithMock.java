package lithan.training.LithanSpringKYN.test;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.util.Assert;

import lithan.training.LithanSpringKYN.config.JPAConfig;
import lithan.training.LithanSpringKYN.config.SecurityConfig;
import lithan.training.LithanSpringKYN.config.WebMvcConfig;
import lithan.training.LithanSpringKYN.daos.StoreRepository;
import lithan.training.LithanSpringKYN.entities.Store;
import lithan.training.LithanSpringKYN.services.StoreService;

@ExtendWith(SpringExtension.class)
@ContextConfiguration(classes={WebMvcConfig.class, JPAConfig.class, SecurityConfig.class})
@WebAppConfiguration
public class KYN_Unit_TestwithMock {

	/* Autowire in the service we want to test */
	@Autowired
	private StoreService storeService;

	/** Create a mock implementation of the StoreRepository */
	@Mock
	private StoreRepository storeRepository;

	@Bean
	public StoreService storeService() {
		return new StoreService();
	}


	@Test
	 public void testGetAllStore() {
		
		//Setup our mock repository
		List<Store> mockstores = new ArrayList<Store>();
        Store s1 = new Store((long)33, "store Name", "phonenumber","Email", "Address");
        Store s2 = new Store((long)22, "store Name2", "phonenumber2","Email2", "Address2");
        mockstores.add(s1);
        mockstores.add(s2);
        Mockito.when(storeRepository.findAll()).thenReturn(mockstores);
		
        // Assert the response
        Assertions.assertEquals(2, mockstores.size());
 

	 }

}
